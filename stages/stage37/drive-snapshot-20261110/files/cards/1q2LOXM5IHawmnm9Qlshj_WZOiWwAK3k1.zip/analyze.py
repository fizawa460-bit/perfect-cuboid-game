import os
ROOT=os.path.dirname(os.path.abspath(__file__))
import sympy as s, itertools, json, collections, time
t,X,Y=s.symbols('t X Y')
codes=[k for k in itertools.product([-1,0,1],repeat=3) if any(k) and next(z for z in k if z)!=1]
def E(k):
 i,j,k=k
 return s.expand((i*t+j*X+k*Y-i*j*k*t*X*Y)**2*((1+t*t) if i==0 else 1)*((1+X*X) if j==0 else 1)*((1+Y*Y) if k==0 else 1))
def key(tr,h):return '.'.join(''.join(str(z+1) for z in k) for k in tr)+':'+str(h)
triples=[tr for tr in itertools.combinations(codes,3) if all(sum(k[j]==0 for k in tr)<=1 for j in range(3))]
assert len(codes)==13 and len(triples)==138
out=[];counts=collections.Counter()
for tr in triples:
 for h in range(3):
  F=s.expand(sum((1 if j!=h else -1)*E(k) for j,k in enumerate(tr)))
  px=s.Poly(F,X); DX=s.factor(s.discriminant(px.as_expr(),X))
  odd=[f for f,e in s.factor_list(DX)[1] if e%2 and s.degree(f,Y)>0]
  genusdeg=sum(s.degree(f,Y) for f in odd)
  P=s.Poly(F,Y); A,B,C=[P.nth(j) for j in (2,1,0)]
  Norm=s.factor((A-C)**2+B**2)
  fl=s.factor_list(Norm)[1]
  record={'key':key(tr,h),'discdeg':int(genusdeg),'F':str(F),'norm':str(Norm),'factors':[(str(f),int(e),int(s.degree(f,X)),int(s.degree(f,t))) for f,e in fl]}
  out.append(record)
  if genusdeg>=3:counts[tuple((e,int(s.degree(f,X)),int(s.degree(f,t))) for f,e in fl)]+=1
json.dump(out,open(os.path.join(ROOT,'all414.json'),'w'),indent=2)
print('generic330',sum(z['discdeg']>=3 for z in out),flush=True)
for k,v in counts.items():print(v,k,flush=True)
print('distinct residual factors')
fac={f for z in out if z['discdeg']>=3 for f,e,dx,dt in z['factors'] if dx and f!='X**2 + 1'}
for f in sorted(fac):print(f,flush=True)
