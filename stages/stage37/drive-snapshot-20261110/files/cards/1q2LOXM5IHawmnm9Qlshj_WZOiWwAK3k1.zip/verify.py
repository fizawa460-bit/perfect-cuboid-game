import sympy as s,json,collections,hashlib,math
from pathlib import Path
root=Path(__file__).resolve().parent
data=json.load(open(root/'all414.json')); ext=json.load(open(root/'extension.json'))
t,X,Y,a,b,c,d=s.symbols('t X Y a b c d')
assert len(data)==414 and sum(z['discdeg']>=3 for z in data)==330
assert ext['counts']=={'0':198,'2':42,'4':90}
orig22=set(('000.010.022:0 000.010.022:2 000.010.100:0 000.010.100:1 000.010.100:2 '
'000.012.022:0 000.012.022:2 000.022.110:0 002.010.020:0 002.010.020:2 '
'002.012.020:2 002.012.102:0 002.012.102:1 002.012.102:2 002.020.110:0 '
'002.020.110:1 010.020.102:0 010.020.102:1 010.020.102:2 '
'012.022.100:0 012.022.100:1 012.022.100:2').split())
qkeys=set(z['key'] for z in ext['quadratic']);assert orig22<qkeys and len(qkeys-orig22)==20
D1=a*a-3*b*b;D2=3*a*a-b*b;D3=(a*a+b*b)**2-16*a*a*b*b
matchecks=0;denoms=set();mult=[]
for z in ext['quadratic']:
 H=s.sympify(z['H']);L=s.sympify(z['L']);K=s.sympify(z['K']);m=list(map(s.sympify,z['matrix']))
 conjugate=lambda f:s.conjugate(f).subs({s.conjugate(v):v for v in [t,X,a,b,c,d]})
 assert s.expand(H-K*L*conjugate(L))==0
 Li=s.expand((m[0]+s.I*m[2])*c+(m[1]+s.I*m[3])*d)
 assert s.expand(Li-z['denom']*a**z['td']*c*L.subs({t:b/a,X:d/c}))==0
 det=s.sympify(z['det']); assert s.expand(det-(m[0]*m[3]-m[1]*m[2]))==0
 div=s.cancel(D1*D2*D3*(a*a+b*b)/det)
 assert s.denom(div)==1
 assert z['denom'] in [1,3] and K in [1,9]
 matchecks+=1
 denoms.add(z['denom'])
 # homogeneous integer S0=a^4*c^4*S, remove physical p/q norm factors exactly.
 src=next(v for v in data if v['key']==z['key']); F=s.sympify(src['F']);P=s.Poly(F,Y)
 norm=s.expand((P.nth(2)-P.nth(0))**2+P.nth(1)**2)
 S0=s.expand(s.cancel(a**4*c**4*norm.subs({t:b/a,X:d/c})))
 N=s.expand(Li*conjugate(Li)); quotient=s.factor(s.cancel(S0/N))
 num,den=s.fraction(quotient);facs=s.factor_list(num)[1]+s.factor_list(den)[1]
 assert all(f in [a*a+b*b,c*c+d*d] for f,e in facs),(z['key'],quotient)
 mult.append({'key':z['key'],'S0_div_N':str(quotient)})
# Norm identity for both rational roots, including scalar square class.
for key in ext['squarekeys']:
 src=next(v for v in data if v['key']==key);num,fl=s.factor_list(s.sympify(src['norm']))
 assert s.sqrt(num).is_Rational
 assert all(e%2==0 or f in [1+t*t,1+X*X] for f,e in fl)
summary={'enumeration':[13,138,414],'generic_count':330,'classification':ext['counts'],
'linear_matrix_exact_checks':matchecks,'new_keys':sorted(qkeys-orig22),
'all42_determinants_divide_D1_D2_D3_p2':True,'S0_div_norm_identities':mult,
'square_kernel_exact_checks':198,'quartic_residual_count':90,
'global_count_improved':False,'gate':'OPEN','credit':0,'production':'HOLD','route_switch':'NONE'}
for f in ['analyze.py','extend.py','verify.py','all414.json','extension.json']:
 summary.setdefault('sha256',{})[f]=hashlib.sha256((root/f).read_bytes()).hexdigest()
json.dump(summary,open(root/'certificate.json','w'),indent=2)
print(json.dumps({k:v for k,v in summary.items() if k not in ['S0_div_norm_identities','new_keys','sha256']},indent=2))
print('NEW20',' '.join(summary['new_keys']))
print('EXAMPLE_S0_OVER_N',mult[0])
# Actual alternate raw edge-support enumeration, no claim of physical points.
def singleton_large(n,Z):
 for p in s.factorint(n):
  if p>Z and n%int(p)**2:return True
 return False
fixtures=[]
for XX,Z in [(10000,100),(30000,200)]:
 count=sum(singleton_large(n,Z) for n in range(1,XX+1))
 fixtures.append({'edge_bound':XX,'singleton_prime_threshold':Z,'raw_edges_surviving':count,'physical_count':None})
summary['alternative_high_Gres_edge_tail_fixtures']=fixtures
json.dump(summary,open(root/'certificate.json','w'),indent=2)
print('ALTERNATE_RAW_EDGE_SUPPORT_ONLY',fixtures)
