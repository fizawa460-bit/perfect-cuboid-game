import os
ROOT=os.path.dirname(os.path.abspath(__file__))
import sympy as s,json,collections,math
t,X=s.symbols('t X'); a,b,c,d=s.symbols('a b c d');I=s.I
data=json.load(open(os.path.join(ROOT,'all414.json')))
summary=collections.Counter(); quadratic=[]; squarekeys=[];quartickeys=[]
for z in data:
 if z['discdeg']<3:continue
 residual=[(s.sympify(f),e) for f,e,dx,dt in z['factors'] if f not in ['X**2 + 1','t**2 + 1'] and e%2]
 deg=sum(s.degree(f,X) for f,e in residual);summary[int(deg)]+=1
 if deg==0:squarekeys.append(z['key'])
 elif deg==4:quartickeys.append(z['key'])
 elif deg==2:
  assert len(residual)==1
  H=residual[0][0]
  delta=s.factor(s.discriminant(H,X)); root=s.sqrt(-delta/4)
  fac=s.factor_list(H,extension=I)[1]
  assert len(fac)==2 and all(s.degree(f,X)==1 and e==1 for f,e in fac),(z['key'],fac)
  L=fac[0][0]
  Re=s.expand(s.re(L.expand(complex=True))) if False else s.expand((L+s.conjugate(L).subs({s.conjugate(t):t,s.conjugate(X):X}))/2)
  Im=s.expand((L-s.conjugate(L).subs({s.conjugate(t):t,s.conjugate(X):X}))/(2*I))
  K=s.cancel(H/(Re**2+Im**2))
  assert not K.has(X)
  # Integer homogeneous linear form in c,d; clear rational numeric denominator.
  coeff=s.Poly(Re+I*Im,X)
  td=max(s.degree(s.re(v).expand(complex=True),t) if False else s.degree(v,t) for v in coeff.all_coeffs())
  Lint=s.expand(s.cancel(a**td*c*L.subs({t:b/a,X:d/c})))
  denom=s.ilcm(*[s.denom(v) for v in s.Poly(Lint,a,b,c,d).all_coeffs()]) if False else s.ilcm(*[s.denom(v) for v in s.Poly(Lint,a,b,c,d).coeffs()])
  Lint=s.expand(denom*Lint)
  re=s.expand((Lint+s.conjugate(Lint).subs({s.conjugate(v):v for v in [a,b,c,d]}))/2)
  im=s.expand((Lint-s.conjugate(Lint).subs({s.conjugate(v):v for v in [a,b,c,d]}))/(2*I))
  matrix=[s.diff(re,c),s.diff(re,d),s.diff(im,c),s.diff(im,d)]
  determinant=s.factor(matrix[0]*matrix[3]-matrix[1]*matrix[2])
  const=s.factor(K)
  record={'key':z['key'],'H':str(H),'delta':str(delta),'L':str(L),'K':str(const),'td':int(td),'matrix':[str(v) for v in matrix],'det':str(determinant),'denom':int(denom)}
  quadratic.append(record)
else:pass
out={'counts':dict(summary),'quadratic':quadratic,'squarekeys':squarekeys,'quartickeys':quartickeys}
json.dump(out,open(os.path.join(ROOT,'extension.json'),'w'),indent=2)
print('RESIDUAL_DEGREES',summary)
print('QUADRATIC_KEYS',len(quadratic),'unique_H',len(set(z['H'] for z in quadratic)))
for z in sorted({(z['det'],z['K'],z['denom']) for z in quadratic}):print(z)
